from django.contrib import admin
from django.urls import path
from studentapp.views import Home,loginpage,logout,index,marks
urlpatterns = [
    path('',Home),
    path('login/',loginpage),
    path('logout/',logout),
    path('admin/', admin.site.urls),
    path('index/',index),
    
    path('marks/',marks),
]

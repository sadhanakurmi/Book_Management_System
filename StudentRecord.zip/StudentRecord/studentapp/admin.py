from django.contrib import admin

from.models import Studentdata

admin.site.register(Studentdata)

from.models import StudentMarks

admin.site.register(StudentMarks)
# Register your models here.

